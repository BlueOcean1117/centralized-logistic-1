
import React from 'react';
import Wizard from './wizard/Wizard';
function App(){
  return (
    <div style={{padding:'20px'}}>
      <h1>Centralized Logistics ERP</h1>
      <Wizard/>
    </div>
  );
}
export default App;
